#ifndef POLYGON_H
#define POLYGON_H
#include "Shape.h"

class Polygon: public Shape {
    float x;
    float y;
    int sides;
    float length;
    float r;
    float g;
    float b;

public:
    Polygon();
    Polygon(float x, float y, int sides, float length, float r, float g, float b);

    void draw();
    bool contains(float mx, float my);
    void setColor(float r, float g, float b);

    float getR() const;
    float getG() const;
    float getB() const;

    void makeSize(float newSize);
    float seeSize()const;
    
};

#endif