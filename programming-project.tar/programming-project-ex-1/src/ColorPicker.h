#ifndef COLOR_PICKER_H
#define COLOR_PICKER_H

#include <bobcat_ui/all.h>

class ColorPicker : public bobcat::Window {
    Fl_Color_Chooser* chooser;
    bobcat::Button* okButton;

    void onClick(bobcat::Widget* sender);

public:
    ColorPicker(int x, int y, int w, int h);

    double getR() const;
    double getG() const;
    double getB() const;
};

#endif
