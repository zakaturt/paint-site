#include "ColorPicker.h"
using namespace bobcat;

ColorPicker::ColorPicker(int x, int y, int w, int h) : Window(x, y, w, h, "Color Picker") {
    chooser = new Fl_Color_Chooser(10, 10, w - 20, h - 60, "");
    chooser->rgb(1.0, 1.0, 1.0);

    okButton = new Button( w / 2 - 40, h - 40, 80, 30,"OK");
    okButton->callback([](Fl_Widget* w, void* data) {
        static_cast<ColorPicker*>(data)->onClick(w);
    }, this);

    this->add(chooser);
    this->add(okButton);

    this->show();
}

void ColorPicker::onClick(bobcat::Widget* sender) {
    this->hide();
}

double ColorPicker::getR() const {
    return chooser->r();
}

double ColorPicker::getG() const {
    return chooser->g();
}

double ColorPicker::getB() const {
    return chooser->b();
}
