#include "Scribble.h"

void Scribble::addPoint(float x, float y, float r, float g, float b, int size){
    points.push_back(new Point(x, y, r, g, b, size));
}

void Scribble::draw(){
    for (unsigned int i = 0; i < points.size(); i++){
        points[i]->draw();
    }
}

Scribble::~Scribble(){
    for (unsigned int i = 0; i < points.size(); i++){
        delete points[i];
    }
    points.clear();
}

bool Scribble::contains(float mx, float my) {
    for (unsigned int i = 0; i < points.size(); i++) {
        if (points[i]->contains(mx, my)) {
            return true;
        }
    }
    return false;
}

void Scribble::setColor(float r, float g, float b) {
    for (unsigned int i = 0; i < points.size(); i++) {
        points[i]->setColor(r, g, b);
    }
}

float Scribble::getR() const {
    if (!points.empty()) {
        return points[0]->getR();
    }
    return 0;  // fallback value
}

float Scribble::getG() const {
    if (!points.empty()) {
        return points[0]->getG();
    }
    return 0;
}

float Scribble::getB() const {
    if (!points.empty()) {
        return points[0]->getB();
    }
    return 0;
}

void Scribble::makeSize(float newSize) {
    for (Point* p : points) {
        p->makeSize(newSize);
    }
}
float Scribble::seeSize() const {
    if (!points.empty()) return points[0]->getSize();
    return 1.0f; // fallback if empty
}


