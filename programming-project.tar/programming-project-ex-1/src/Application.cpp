#include "Application.h"
#include "Enums.h"
#include <bobcat_ui/bobcat_ui.h>

using namespace bobcat;
using namespace std;

void Application::onCanvasMouseDown(bobcat::Widget* sender, float mx, float my) {
    TOOL tool = toolbar->getTool();
    Color color = colorSelector->getColor();

    if (tool == PENCIL) {
        canvas->startScribble();
        canvas->updateScribble(mx, my, color.getR(), color.getG(), color.getB(), 7);
        canvas->redraw();
    }
    else if (tool == ERASER) {
        selectedShape = canvas->getErasedShape(mx, my);
        canvas->redraw(); 
        
    }
    else if (tool == RECTANGLE) {
        canvas->addRectangle(mx, my, 0.4, 0.4, color.getR(), color.getG(), color.getB());
        canvas->redraw();
    }
    else if (tool == CIRCLE) { 
        canvas->addCircle(mx, my, 0.2, color.getR(), color.getG(), color.getB());
        canvas->redraw();
    }
    else if (tool == POLYGON) {
        canvas->addPolygon(mx, my, 6 , 0.2,  color.getR(), color.getG(), color.getB());
        canvas->redraw();
    }
    else if (tool == TRIANGLE) {
        canvas->addTriangle(mx, my, 0.2, 0.2 , color.getR(), color.getG(), color.getB());
        canvas->redraw();
    }
    else if (tool == MOUSE) {
        selectedShape = canvas->getSelectedShape(mx, my);
    }
}

void Application::onCanvasMouseUp(bobcat::Widget* sender, float mx, float my) {
    canvas->endScribble();
}

void Application::onCanvasDrag(bobcat::Widget* sender, float mx, float my) {
    TOOL tool = toolbar->getTool();
    Color color = colorSelector->getColor();
    if (tool == PENCIL) {
        canvas->updateScribble(mx, my, color.getR(), color.getG(), color.getB(), 7);
        canvas->redraw();
    }
    else if (tool == ERASER) {
        canvas->updateScribble(mx, my, 1, 1, 1, 14);
        canvas->redraw();
    }
    else if(tool == MOUSE){
        
    }
}

void Application::onToolbarChange(bobcat::Widget* sender) {
    ACTION action = toolbar->getAction();

    if (action == CLEAR) {
        canvas->clear();
        canvas->redraw();
    }
    else if (action == SENDBACK){
        if (selectedShape) {
            canvas->front(selectedShape);
            canvas->redraw();
        }
    }
    else if (action == BRINGFRONT){
        if (selectedShape) {
            canvas->back(selectedShape);
            canvas->redraw();
        }
    }

    else if (action == PLUS){
        if (selectedShape){
            std::cout << "Resizing shape from size " << selectedShape->seeSize() << std::endl;
            selectedShape->makeSize(selectedShape->seeSize() + 1);
            canvas->redraw();
        }
    }
    else if (action == MINUS){
        if (selectedShape){
            std::cout << "Resizing shape from size " << selectedShape->seeSize() << std::endl;
            selectedShape->makeSize(selectedShape->seeSize() - 1);
            canvas->redraw();
        }
    }
    
}

void Application::onColorSelectorChange(bobcat::Widget* sender) {
    Color color = colorSelector->getColor();

    if (selectedShape) {
        cout << "Update selected shape color" << endl;
        selectedShape->setColor(color.getR(), color.getG(), color.getB());
        canvas->redraw();
    }
}




Application::Application() {
    window = new Window(25, 75, 600, 600, "Paining ");

    toolbar = new Toolbar(0, 0, 50, 400);
    canvas = new Canvas(50, 0, 550, 550);
    colorSelector = new ColorSelector(50, 550, 550, 50);
    colorSelector->box(FL_BORDER_BOX);

    window->add(toolbar);
    window->add(canvas);
    window->add(colorSelector);

    ON_MOUSE_DOWN(canvas, Application::onCanvasMouseDown);
    ON_DRAG(canvas, Application::onCanvasDrag);
    ON_CHANGE(toolbar, Application::onToolbarChange);
    ON_CHANGE(colorSelector, Application::onColorSelectorChange);

    window->show();
}
