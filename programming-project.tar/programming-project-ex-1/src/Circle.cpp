#include "Circle.h"
#include <GL/freeglut.h>
#include <GL/gl.h>
#include <cmath>

Circle::Circle() {
    x = 0.0;
    y = 0.0;
    radius = 0.2;
    r = 0.0;
    g = 0.0;
    b = 0.0;
}

Circle::Circle(float x, float y,float radius, float r, float g, float b) {
    this->x = x; 
    this->y = y; 
    this->radius = radius;
    this->r = r; 
    this->g = g; 
    this->b = b; 
}

void Circle::draw() {
    glColor3f(r, g, b);

    float inc = M_PI / 32;
    glBegin(GL_POLYGON);
        for (float theta = 0; theta <= 2 * M_PI; theta += inc){
            glVertex2d(x + cos(theta) * radius, y + sin(theta) * radius);
        }
    glEnd();
}

bool Circle::contains(float mx, float my) {
    float dx = mx - this->x;
    float dy = my - this->y;
    float distanceSquared = dx * dx + dy * dy;
    return distanceSquared <= this->radius * this->radius;
}

void Circle::setColor(float r, float g, float b) {
    this->r = r;
    this->g = g;
    this->b = b;
}

void Circle::makeSize(float newSize) { radius = newSize; }
float Circle::seeSize() const { return radius; }




float Circle::getR() const { return r; }
float Circle::getG() const { return g; }
float Circle::getB() const { return b; }
