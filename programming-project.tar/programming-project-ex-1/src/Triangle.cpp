#include "Triangle.h"
#include <GL/freeglut.h>
#include <cmath>
Triangle::Triangle() {
    x = 0.0;
    y = 0.0;
    base = 0.2;
    height = 0.2;
    r = 0.0;
    g = 0.0;
    b = 0.0;
}

Triangle::Triangle(float x, float y, float base, float height, float r, float g, float b) {
    this->x = x;
    this->y = y;
    this->base = base;
    this->height = height;
    this->r = r;
    this->g = g;
    this->b = b;
}

void Triangle::draw() {
    glColor3f(r, g, b);
    
    glBegin(GL_POLYGON);
        glVertex2f(x - base/2, y - height/2);
        glVertex2f(x, y + height/2);
        glVertex2f(x + base/2, y - height/2);
    glEnd();
}

bool Triangle::contains(float mx, float my) {

    float left = x - base / 2;
    float right = x + base / 2;
    float bottom = y - height / 2;
    float top = y + height / 2;

    if (mx < left || mx > right || my < bottom || my > top) {
        return false;
    }

    float dx = mx - x;
    float dy = my - (y - height / 2);

    float slope = (base / 2) / height;
    float max_dx = slope * dy;

    if (fabs(dx) <= max_dx) {
        return true;
    }

    return false;
}

void Triangle::setColor(float r, float g, float b) {
    this->r = r;
    this->g = g;
    this->b = b;
}
void Triangle::makeSize(float newSize) { base = height = newSize; }
float Triangle::seeSize() const { return base; }  // or height, if same


float Triangle::getR() const { return r; }
float Triangle::getG() const { return g; }
float Triangle::getB() const { return b; }