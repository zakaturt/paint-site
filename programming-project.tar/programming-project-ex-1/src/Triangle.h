#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "Shape.h"

class Triangle: public Shape {
    float x;
    float y;
    float base;
    float height;
    float r;
    float g;
    float b;

public:
    Triangle();
    Triangle(float x, float y, float base, float height, float r, float g, float b);

    void draw();
    bool contains(float mx, float my);
    void setColor(float r, float g, float b);

    float getR() const;
    float getG() const;
    float getB() const;

    void makeSize(float newSize);
    float seeSize()const;
    
};

#endif