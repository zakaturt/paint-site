#include "Canvas.h"
using namespace std;
#include <algorithm>
#include <cstdlib>
#include <GL/freeglut.h>


Canvas::Canvas(int x, int y, int w, int h) : Canvas_(x, y, w, h) {
    curr = nullptr;
}

void Canvas::addPoint(float x, float y, float r, float g, float b, int size) {
    shapes.push_back(new Point(x, y, r, g, b, size));
}

void Canvas::addRectangle(float x, float y,float width, float height, float r, float g, float b) {
    shapes.push_back(new Rectangle(x, y,width , height, r, g, b));
}

void Canvas::addCircle(float x, float y,float radius, float r, float g, float b) {
    shapes.push_back(new Circle(x, y,radius, r, g, b));
}

void Canvas::addPolygon(float x, float y, int sides, float length, float r, float g, float b){
    shapes.push_back(new Polygon(x ,y, sides, length, r , g, b));
}

void Canvas::addTriangle(float x, float y, float base, float height, float r, float g, float b){
    shapes.push_back(new Triangle(x ,y, base, height, r , g, b));
}

void Canvas::clear() {
    for (unsigned int i = 0 ; i < shapes.size(); i++) {
        delete shapes[i];
    }
    shapes.clear();

    if (curr) {
        delete curr;
        curr = nullptr;
    }
}


Shape* Canvas::getSelectedShape(float mx, float my) {
    Shape* selectedShape = nullptr;

    for (unsigned int i = 0; i < shapes.size(); i++) {
        // ask every shape if we clicked on it
        if (shapes[i]->contains(mx, my)) {
            std::cout << "Clicked on shape[" << i << "]" << std::endl;
            selectedShape = shapes[i];
            break;
        }
    }

    if (selectedShape == nullptr) {
        std::cout << "No selected shape" << std::endl;
    }

    return selectedShape;
}

Shape* Canvas::getErasedShape(float mx, float my) {
    Shape* selectedShape = nullptr;

    for (unsigned int i = 0; i < shapes.size(); i++) {
        // ask every shape if we clicked on it
        if (shapes[i]->contains(mx, my)) {
            if (shapes[i]->getR() == 1 && shapes[i]->getG() == 1 && shapes[i]->getB() == 1) {
                continue;  // skip to next shape
            }
            std::cout << "Clicked on shape[" << i << "]" << std::endl;
            selectedShape = shapes[i];
            selectedShape->setColor(1, 1, 1);
            break;
        }
        
    }//add a if statement for when selcted color is white then skip and find other stuff ...

    if (selectedShape == nullptr) {
        std::cout << "No selected shape" << std::endl;
    }

    return selectedShape;
}

void Canvas::front(Shape* shape) {
    shapes.push_back(shape);;
}

void Canvas::back(Shape* shape) {
    shapes.insert(shapes.begin(),shape);
}





void Canvas::big(float mx, float my){
    
}

void Canvas::small(float mx, float my){

}

void Canvas::render() {
    for (unsigned int i = 0 ; i < shapes.size(); i++) {
        shapes[i]->draw();
    }
    if (curr){
        curr->draw();
    }   
}

void Canvas::startScribble(){
    if (!curr) {  
        curr = new Scribble();
    }
}

void Canvas::updateScribble(float x, float y, float r, float g, float b, int size){
    if (curr){
        curr->addPoint(x, y, r, g, b, size);
    }
}

void Canvas::endScribble(){
    if (curr){
        shapes.push_back(curr);
        curr = nullptr;
    }
}
