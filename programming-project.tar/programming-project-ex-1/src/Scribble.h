#ifndef SCRIBBLE_H
#define SCRIBBLE_H

#include "Shape.h"
#include "Point.h"
#include <vector>

class Scribble: public Shape {
    std::vector<Point*> points;
    //std::vector<Shape*> shapes;
public:

    void addPoint(float x, float y, float r, float g, float b, int size);
    
    void draw();
    bool contains(float mx, float my);
    void setColor(float r, float g, float b);

    ~Scribble();

    float getR() const;
    float getG() const;
    float getB() const;

    void makeSize(float newSize);
    float seeSize()const;
};
#endif